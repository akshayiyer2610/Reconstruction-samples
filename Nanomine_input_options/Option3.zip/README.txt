Input Option 3: Multiple JPEG images in zip file

Submit a ZIP file containing multiple JPEG images of same size (in pixels). 
DO NOT ZIP the folder containing images; select all images and ZIP them directly.

This folder contains a ZIP file ("TEM images.zip") that contains four JPEG images:

1.jpg
2.jpg
image3.jpg
sample4.jpg

Name of images and ZIP file is irrelevant.
Images may or may not be in RGB format but, they must have same resolution (in pixels).
