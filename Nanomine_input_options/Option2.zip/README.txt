Input Option 1: Single image in .mat format

Submit a .mat (MATLAB native format) containing binarized image.

This folder contains one .mat file:

my_image.mat {contains one varilable "Input" - 200 x 200}

Name of .mat file is irrelevant but it must contain ONLY ONE variable named "Input" - the binarized image.

