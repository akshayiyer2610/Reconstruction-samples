Input Option 1: Single JPEG image

Submit a binarized JPEG image.

This folder contains one JPEG image:

1.jpg

Name and size of images is irrelevant.
Image may or may not be in RGB format but, they must have same resolution (in pixels).
